contatore = 0
separatore = ","
file=open("OrarioTabellaGlobale.csv", "r")
elenco_giorni={
    "Lunedì":0,
    "Martedì":1,
    "Mercoledì":2,
    "Giovedì":3,
    "Venerdì":4,
}
def Docenti_Ora(giorno,ora):
    '''
    Restituisce un file con l'elenco di tutti i docenti avente lezione in una determinata ora di un determinato giorno
    
    Parametri:
        giorno: chiede il giorno della settimana
        es: (Lunedì)
        
        ora:    chide l'ora del giorno scelto
        es: (4)
    Ritorna:
        Questa funzione restituisce un file avente i docenti che hanno lezione nel giorno e l'ora specificati
    '''
    file01 = open("lezioni_ora.txt", "w")
    posizione = 8 * elenco_giorni[giorno] + ora
    file.readline()
    file.readline()
    riga=file.readline().strip

    while riga != "":
        riga=riga.split(separatore)
        if riga[posizione] != "   ":
            file01.write(riga[0]+ "\n")
            contatore +=1
        riga=file.readline().strip()
        contatore= str(contatore)
        file01.write(contatore)