#Alessandro Contri 3GI 17/04/2024
Separatore = ","
def Ore_Disponibili_Docente(nome):
    '''
    Restituisce un file contenente le ore libere di un docente (D)
    
    Parametri:
        nome: nome del docente di cui si vogliono sapere le ore libere
        es:(BATTAGLIA ELENA RITA)

    Ritorna:
        File contenente le ore libere del professore
    '''
    file=open("OrarioTabellaGlobale.csv", "r")
    file02= open("ore_liberetxt", "w")
    
    contatore=0

    riga=file.readline().strip()

    while riga != "":
        riga.split(Separatore)
        nome_docente = riga[0]
        if nome_docente == nome:
            for elemento in riga:
                ore= elemento.strip
            if ore == 'D':
                contatore =+1
        riga=file.readline().strip()
    contatore = str(contatore)
    file02.write(contatore)



