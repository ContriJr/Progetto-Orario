#Alessandro Contri 3GI 10/04/2024
#Elenco dei docenti di una determinata classe
import os
#richiestaclasse= input("inserisci la classe: ")

def Docenti_Classe(richiestaclasse):                #funzione che dopo aver inserito una classe in input crea file con lista di tutti i professori di quella classe
    '''
    Restituisce l'elenco dei docenti di una classe

    Parametri:
        richiestaclasse= Nome della classe da cercare
        es: (2HL)
    
    Ritorna:
        Questa funzione crea un file di nome "docenti_classe.txt" in cui sono presenti gli insegnanti di quella classe
    '''
    nuovofile=open("docenti_classe.txt","w")
    f=open("OrarioTabellaGlobale.csv", "r")
    nuovariga = f.readline()
    while nuovariga != "":
        nuovariga = nuovariga.strip().split(",")
        for i in nuovariga:
            if i == richiestaclasse:
                print(nuovariga[0]+'\n')
                nuovofile.write(nuovariga[0]+ '\n')
        nuovariga = f.readline()
   
    f.close()
    nuovofile.close()
